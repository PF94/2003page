For anyone wondering, this is a sandbox for testing Bootstrap 5, which once out of beta, will be used in all of the primary 2003page stuff.

Bootstrap 5 is still incomplete, thus, in order to interfere the daily 2003page (currently on a version of Bootstrap 4) shenanigans.

Shit will break from time to time. Don't worry.

IMPORTANT INFOMATION

2003PAGE'S BRANDING IS $purple-500 FOR BOOTSTRAP 5, and yes, the design (as of writing this) is a placeholder, new logo will be SVG. -PF94

TODO: GET SASS TO WORK, I SWEAR TO FUCKING GOD, THIS IS USEFUL, I SWEAR.