Emoticons for 2003page! :D


These are added because they can be used for blogs or just replace text emoticons :P

we are including:

MSN, AIM LARGE, AIM SMALL, YAHOO